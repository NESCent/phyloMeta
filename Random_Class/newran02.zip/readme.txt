Newran02 C++ random number generator library.

Documentation is in nr02doc.htm.

